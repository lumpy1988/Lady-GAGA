package view;

import java.awt.Color;
import java.awt.Cursor;

import javax.swing.AbstractButton;
import javax.swing.ImageIcon;

class ButtonRollover {

    private String normalImagePath;
    private String rolloverImagePath;
    private String pressedImagePath;

    public ButtonRollover(String normalImagePath, String rolloverImagePath, String pressedImagePath) {
        this.normalImagePath = normalImagePath;
        this.rolloverImagePath = rolloverImagePath;
        this.pressedImagePath = pressedImagePath;
    }

    public void apply(AbstractButton abstractButton) {
        abstractButton.setBorderPainted(false);
        abstractButton.setBackground(new Color(0, 0, 0, 0));
        abstractButton.setRolloverIcon(createImageIcon(rolloverImagePath));
        abstractButton.setPressedIcon(createImageIcon(pressedImagePath));
        abstractButton.setIcon(createImageIcon(normalImagePath));
        abstractButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private ImageIcon createImageIcon(String path) {
        java.net.URL imgURL = getClass().getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }
}