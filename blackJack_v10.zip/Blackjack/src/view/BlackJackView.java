/**
 * @author Idan , Kosta , Or , Elinor
 */
package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import controller.BlackJackController;
import model.PlayerType;


/**
 * BlackJackView Class MVS - View
 */
public class BlackJackView {
	/**
	 * parameters
	 */
	private static JFrame frmBlackjack; // main frame
	private ArrayList<JLabel> dealerLabels = null; // dealer cards
	private ArrayList<JLabel> userLabels = null; // user cards
	private ArrayList<JLabel> unfoldUserCards = null; // user's unfold cards for the deal movement
	private ArrayList<JLabel> unfoldDealerCards = null; // dealer unfold cards for the deal movement 
	private static JLabel background = null; // background of the main frame
	private BlackJackController myController; // controller instance
	private JButton btnDeal = new JButton("Deal"); // Deal button
	private JButton btnHit = new JButton(); // Hit button
	private JButton btnStand = new JButton(); // Stand button
	private JButton btnReset = new JButton(); // reset button
	private JLabel userScoreValue = new JLabel(); // user score graphics
	private JLabel dealerScoreValue = new JLabel(); // dealer score graphics
	private JLabel messageBoard = new JLabel(); // message board
	private JLabel roundboard = new JLabel(); // round board
	private JLabel light = new JLabel(); // light bulb
	private JButton bet_2 = new JButton(); // bet 2 button
	private JButton bet_5 = new JButton(); // bet 5 button
	private JButton bet_10 = new JButton(); // bet 10 button
	private JButton bet_100 = new JButton(); // bet 100 button
	private JButton btnClear = new JButton(); // bet clear button
	private JLabel currentBet = new JLabel(); // current bet board
	private JLabel totalScore = new JLabel(); // total score board 
	private int numberOfUserCards = 0; // indicate the number of cards in the user hand
	private int numberOfDealerCards = 0; // indicate the number of cards in the dealer hand
	private javax.swing.Timer animationCleanBet = null; // timer to clean the bet score after a round
	private javax.swing.Timer timerToSetDealerMoves = null; // timer to start the dealer moves
	private boolean isUserWon = false; // indicates the game status
	private boolean isAnimation = false; // indicates whatever there is an animation or not

	/**
	 * BlackJackView Constructor
	 */
	public BlackJackView() 
	{
		initialize();
	}

	/**
	 * sets the controller instance
	 * 
	 * @param BlackJackController
	 */
	public void setController(BlackJackController c) {
		this.myController = c;
	}

	/**
	 * Launch the application.
	 */
	public void show() {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					frmBlackjack.setVisible(true); // set the frame visible
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		// create the Frame
		createFrame();

		// create the buttons and place them on the frame
		setButtons();

		// create the deck and place it on the frame
		locateDeck();

		// create the light bulb - indication for current player
		locateLight();

		// create the light bulb - indication for current player
		locateMessageBoard();

		// create the round board
		locateRoundBoard();

		// set the round to 0
		updateRoundboard();

		// set the current bet board
		locateCurrentBet();

		// update current bet number
		updateCurrentBet();

		// set the current bet board
		locateTotalScore();

		// update current bet number
		updateTotalScore();

		// set the dealer's delay (timer)
		createTimers();

	}

	/**
	 * creates the timer in order to make the delaer's thinking effect (delay).
	 * creates the timer in order to make the changing point effect.
	 */
	private void createTimers() {
		// defines the timer to delay the dealer moves - dealer is thinking.
		timerToSetDealerMoves = new javax.swing.Timer(
				View_Constants.DELAER_DELAY, new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setDealerMoves();
					}
				});
		// defines the timer to create the changing points effect
		animationCleanBet = new javax.swing.Timer(30, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetCurrentBetAnimation();
			}
		});
	}

	/**
	 * sets the dealer cards graphics.
	 * 
	 * @param ArrayList
	 *            <String>
	 */
	private void setDealerCards(ArrayList<String> cardImages) {
		assert (cardImages.size() == dealerLabels.size());
		for (int i = dealerLabels.size(); i < cardImages.size(); i++) {
			JLabel label = new JLabel();
			java.net.URL sourceimage = getClass().getResource(cardImages.get(i));
			BufferedImage imageOfCard = null;
			try {
				System.out.println(cardImages.get(i));
				imageOfCard = ImageIO.read(sourceimage);
			} catch (IOException e) {
				e.printStackTrace();
			}
			label.setIcon(new ImageIcon(imageOfCard));
			label.setBounds(View_Constants.DEALER_PANE_X_LOCATION
					+ View_Constants.DEALER_PANE_WIDTH
					- View_Constants.DEALER_CARD_WIDTH - (i)
					* View_Constants.SPACE_BETWEEN_CARDS,
					View_Constants.DEALER_PANE_Y_LOCATION
							+ View_Constants.DEALER_CARD_Y_LOCATION,
					View_Constants.DEALER_CARD_WIDTH,
					View_Constants.DEALER_CARD_HEIGHT);
			dealerLabels.add(label);
		}
		// in case the dealer flips his unfold card. no change in his number of
		// cards.
		if (dealerLabels.size() == cardImages.size()) {
			for (int i = 0; i < cardImages.size(); i++) {
				JLabel label = dealerLabels.get(i);
				java.net.URL sourceimage = getClass().getResource(cardImages.get(i));
				BufferedImage imageOfCard = null;
				try {
					imageOfCard = ImageIO.read(sourceimage);
				} catch (IOException e) {
					e.printStackTrace();
				}
				label.setIcon(new ImageIcon(imageOfCard));
				label.setBounds(View_Constants.DEALER_PANE_X_LOCATION
						+ View_Constants.DEALER_PANE_WIDTH
						- View_Constants.DEALER_CARD_WIDTH - (i)
						* View_Constants.SPACE_BETWEEN_CARDS,
						View_Constants.DEALER_PANE_Y_LOCATION
								+ View_Constants.DEALER_CARD_Y_LOCATION,
						View_Constants.DEALER_CARD_WIDTH,
						View_Constants.DEALER_CARD_HEIGHT);
			}
		}
	}

	/**
	 * sets the user cards graphics.
	 * 
	 * @param ArrayList
	 *            <String>
	 */
	private void setUserCards(ArrayList<String> cardImages) {
		assert (cardImages.size() == userLabels.size());
		for (int i = userLabels.size(); i < cardImages.size(); i++) {
			JLabel label = new JLabel();
			java.net.URL sourceimage = getClass().getResource(cardImages.get(i));
			BufferedImage imageOfCard = null;
			try {
				imageOfCard = ImageIO.read(sourceimage);
			} catch (IOException e) {
				e.printStackTrace();
			}
			label.setIcon(new ImageIcon(imageOfCard));
			label.setBounds(View_Constants.USER_PANE_X_LOCATION
					+ ((i) * View_Constants.SPACE_BETWEEN_CARDS),
					View_Constants.USER_PANE_Y_LOCATION
							+ View_Constants.USER_CARD_Y_LOCATION,
					View_Constants.USER_CARD_WIDTH,
					View_Constants.USER_CARD_HEIGHT);
			userLabels.add(label);
		}
	}

	/**
	 * place the deck on the main frame
	 */
	private void locateDeck() {
		try {
			BufferedImage imageToMove = ImageIO.read(getClass().getResource("/resources/deck.png"));
			JLabel deck_pic = new JLabel();
			deck_pic.setIcon(new ImageIcon(imageToMove));
			deck_pic.setBounds(View_Constants.START_POINT_X,
					View_Constants.DECK_Y, View_Constants.USER_CARD_WIDTH,
					View_Constants.DECK_HEIGHT);
			frmBlackjack.getContentPane().add(deck_pic);
		} catch (IOException e1) {
			e1.printStackTrace();
		}

	}

	/**
	 * create the main frame graphics
	 */
	private void createFrame() {
		frmBlackjack = new JFrame();
		try {
			background = new JLabel(new ImageIcon(getClass().getResource("/resources/blackjack table.jpg")));
			frmBlackjack.setContentPane(background);
		} catch (Exception e) {
			e.printStackTrace();
		}
		frmBlackjack.setTitle("BlackJack Game");

		// set the boundaries of the desktop.
		frmBlackjack.setBounds(View_Constants.FRAME_PANE_X_LOCATION,
				View_Constants.FRAME_PANE_Y_LOCATION,
				View_Constants.FRAME_PANE_WIDTH,
				View_Constants.FRAME_PANE_HEIGHT);
		frmBlackjack.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmBlackjack.setResizable(false);
		frmBlackjack.getContentPane().setLayout(null);

	}

	/**
	 * place the buttons on the main frame
	 */
	private void setButtons() {
		// set the pictures of the buttons
		ButtonRollover buttonHitRollover = new ButtonRollover(
				"/resources/hit.png", 
				"/resources/hit_selected.png",
				"/resources/hit_pressed.png");
		buttonHitRollover.apply(btnHit);
		ButtonRollover buttonStandRollover = new ButtonRollover(
				"/resources/stand.png", 
				"/resources/stand_selected.png",
				"/resources/stand_pressed.png");
		buttonStandRollover.apply(btnStand);
		ButtonRollover buttonDealRollover = new ButtonRollover(
				"/resources/deal.png", 
				"/resources/dealSelected.png",
				"/resources/dealPushed.png");
		buttonDealRollover.apply(btnDeal);
		ButtonRollover buttonResetRollover = new ButtonRollover(
				"/resources/resetButton.png",
				"/resources/resetSelected.png",
				"/resources/resetPushed.png");
		buttonResetRollover.apply(btnReset);
		ButtonRollover buttonBet2Rollover = new ButtonRollover(
				"/resources/2_regular.png", 
				"/resources/2_selected.png",
				"/resources/2_pushed.png");
		buttonBet2Rollover.apply(bet_2);
		ButtonRollover buttonBet5Rollover = new ButtonRollover(
				"/resources/5_regular.png", 
				"/resources/5_selected.png",
				"/resources/5_pushed.png");
		buttonBet5Rollover.apply(bet_5);
		ButtonRollover buttonBet10Rollover = new ButtonRollover(
				"/resources/10_regular.png", 
				"/resources/10_selected.png",
				"/resources/10_pushed.png");
		buttonBet10Rollover.apply(bet_10);
		ButtonRollover buttonBet100Rollover = new ButtonRollover(
				"/resources/100_regular.png",
				"/resources/100_selected.png", 
				"/resources/100_pushed.png");
		buttonBet100Rollover.apply(bet_100);
		ButtonRollover buttonClearRollover = new ButtonRollover(
				"/resources/clear_regular.png",
				"/resources/clear_selected.png",
				"/resources/clear_pushed.png");
		buttonClearRollover.apply(btnClear);
		// sets button location
		btnDeal.setBounds(View_Constants.DEAL_PANE_X_LOCATION,
				View_Constants.DEAL_PANE_Y_LOCATION,
				View_Constants.DEAL_PANE_WIDTH, View_Constants.DEAL_PANE_HEIGHT);
		btnHit.setBounds(View_Constants.HIT_PANE_X_LOCATION,
				View_Constants.HIT_PANE_Y_LOCATION,
				View_Constants.HIT_PANE_WIDTH, View_Constants.HIT_PANE_HEIGHT);
		btnStand.setBounds(View_Constants.STAND_PANE_X_LOCATION,
				View_Constants.STAND_PANE_Y_LOCATION,
				View_Constants.STAND_PANE_WIDTH,
				View_Constants.STAND_PANE_HEIGHT);
		btnReset.setBounds(View_Constants.RESET_PANE_X_LOCATION,
				View_Constants.RESET_PANE_Y_LOCATION,
				View_Constants.RESET_PANE_WIDTH,
				View_Constants.RESET_PANE_HEIGHT);
		bet_2.setBounds(View_Constants.BET_X_LOCATION,
				View_Constants.BET_Y_LOCATION, View_Constants.BET_WIDTH,
				View_Constants.BET_HEIGHT);
		bet_5.setBounds(View_Constants.BET_X_LOCATION
				- View_Constants.BET_SPACE, View_Constants.BET_Y_LOCATION,
				View_Constants.BET_WIDTH, View_Constants.BET_HEIGHT);
		bet_10.setBounds(View_Constants.BET_X_LOCATION
				- View_Constants.BET_SPACE * 2, View_Constants.BET_Y_LOCATION,
				View_Constants.BET_WIDTH, View_Constants.BET_HEIGHT);
		bet_100.setBounds(View_Constants.BET_X_LOCATION
				- View_Constants.BET_SPACE * 3, View_Constants.BET_Y_LOCATION,
				View_Constants.BET_WIDTH, View_Constants.BET_HEIGHT);
		btnClear.setBounds(View_Constants.BET_X_LOCATION
				+ View_Constants.BET_SPACE + 5, View_Constants.BET_Y_LOCATION,
				View_Constants.BET_WIDTH, View_Constants.BET_HEIGHT);
		// sets the initial state of the buttons
		btnDeal.setEnabled(true);
		btnHit.setEnabled(false);
		btnStand.setEnabled(false);
		btnReset.setEnabled(true);
		// adds the buttons to the desktop frame
		frmBlackjack.getContentPane().add(btnDeal);
		frmBlackjack.getContentPane().add(btnHit);
		frmBlackjack.getContentPane().add(btnStand);
		frmBlackjack.getContentPane().add(btnReset);
		frmBlackjack.getContentPane().add(bet_2);
		frmBlackjack.getContentPane().add(bet_5);
		frmBlackjack.getContentPane().add(bet_10);
		frmBlackjack.getContentPane().add(bet_100);
		frmBlackjack.getContentPane().add(btnClear);
		setDealFunc(); // sets the Deal functionality
		setHitFunc(); // sets the Hit functionality
		setStandFunc(); // sets the Stand functionality
		setResetFunc(); // sets the Reset functionality
		setBetFunc(); // sets the bet function
	}

	/**
	 * Set the bet buttons functionality.
	 */
	private void setBetFunc() {
		bet_2.addActionListener(new ActionListener() // sets the listener for the "bet 2" button.
		{
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (!isAnimation) {
					if (btnDeal.isEnabled()) {
						if (myController.bet2()) {
							updateBet();
							updateTotalScore();
							setMessageBoard("");
						} else {
							setMessageBoard("Not enough money");
						}
					}
				}
			}
		});

		bet_5.addActionListener(new ActionListener() // sets the listener for the "bet 5" button.
		{
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (!isAnimation) {
					if (btnDeal.isEnabled()) {
						if (myController.bet5()) {
							updateBet();
							updateTotalScore();
							setMessageBoard("");
						} else {
							setMessageBoard("Not enough money");
						}
					}
				}
			}
		});

		bet_10.addActionListener(new ActionListener() // sets the listener for the "bet 10" button.
		{
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (!isAnimation) {
					if (btnDeal.isEnabled()) {
						if (myController.bet10()) {
							updateBet();
							updateTotalScore();
							setMessageBoard("");
						} else {
							setMessageBoard("Not enough money");
						}
					}
				}
			}
		});

		bet_100.addActionListener(new ActionListener() // sets the listener for the "bet 100" button.
		{
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (!isAnimation) {
					if (btnDeal.isEnabled()) {
						if (myController.bet100()) {
							updateBet();
							updateTotalScore();
							setMessageBoard("");
						} else {
							setMessageBoard("Not enough money");
						}
					}
				}
			}
		});

		btnClear.addActionListener(new ActionListener() // sets the listener for the "clear" button.
		{
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (!isAnimation) {
					if (btnDeal.isEnabled()) {
						myController.clearBet();
						updateBet();
						updateTotalScore();
						setMessageBoard("");
					}
				}
			}
		});

	}

	/**
	 * update the current amount of bet according to the buttons
	 */
	private void updateBet() {
		updateCurrentBet();
	}

	/**
	 * Flip the cards after dealing
	 */
	private void flipTheIntialCards() {
		setDealerCards(myController.getDealerStrings());
		setUserCards(myController.getUserStrings());
		// sets the user cards:
		flipCard(PlayerType.USER, 1);
		flipCard(PlayerType.USER, 2);
		// sets the DEALER card (flip only 1 card):
		flipCard(PlayerType.DEALER, 2);

	}

	/**
	 * Flip a card according to the player type and number of card
	 * 
	 * @param PlayerType
	 *            p, int numberOfCard
	 */
	private void flipCard(PlayerType p, int numberOfCard) {
		JLabel lbl = new JLabel("");
		// sets a user card:
		if (p.equals(PlayerType.USER)) {
			lbl = unfoldUserCards.get(numberOfCard - 1);
			int count = lbl.getWidth() / 2;
			for (int i = 0; i < count - 1; i++) // first part of the flip effect - remove the unfold card
			{
				Graphics g = frmBlackjack.getBufferStrategy().getDrawGraphics();
				lbl.setBounds(lbl.getX() + 1, lbl.getY(), lbl.getWidth() - 2,
						lbl.getHeight());
				frmBlackjack.update(g);
				frmBlackjack.getBufferStrategy().show();
				try {
					Thread.sleep(View_Constants.FLIP);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			lbl = userLabels.get(numberOfCard - 1);
			count = lbl.getWidth() / 2;
			Graphics g = frmBlackjack.getBufferStrategy().getDrawGraphics();
			frmBlackjack.update(g);
			lbl.setBounds(lbl.getX() + count, lbl.getY(), 0, lbl.getHeight());
			frmBlackjack.add(lbl, 0);
			frmBlackjack.repaint();
			for (int i = 0; i < count; i++) // second part of the flip effect - reveal the fold card.
			{
				g = frmBlackjack.getBufferStrategy().getDrawGraphics();
				lbl.setBounds(lbl.getX() - 1, lbl.getY(), lbl.getWidth() + 2,
						lbl.getHeight());
				frmBlackjack.update(g);
				frmBlackjack.getBufferStrategy().show();
				g.dispose();
				try {
					Thread.sleep(View_Constants.FLIP);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		} else {
			lbl = unfoldDealerCards.get(numberOfCard - 1);
			int count = lbl.getWidth() / 2;
			for (int i = 0; i < count - 1; i++)// first part of the flip effect - remove the unfold card
			{
				Graphics g = frmBlackjack.getBufferStrategy().getDrawGraphics();
				lbl.setBounds(lbl.getX() + 1, lbl.getY(), lbl.getWidth() - 2,
						lbl.getHeight());
				frmBlackjack.update(g);
				frmBlackjack.getBufferStrategy().show();
				try {
					Thread.sleep(View_Constants.FLIP);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			lbl = dealerLabels.get(numberOfCard - 1);
			count = lbl.getWidth() / 2;
			Graphics g = frmBlackjack.getBufferStrategy().getDrawGraphics();
			frmBlackjack.update(g);
			lbl.setBounds(lbl.getX() + count, lbl.getY(), 0, lbl.getHeight());
			if (numberOfCard == 1) {
				frmBlackjack.add(lbl, 0);
			} else {
				frmBlackjack.add(lbl);
			}
			for (int i = 0; i < count; i++) // second part of the flip effect - reveal the fold card.
			{
				g = frmBlackjack.getBufferStrategy().getDrawGraphics();
				lbl.setBounds(lbl.getX() - 1, lbl.getY(), lbl.getWidth() + 2,
						lbl.getHeight());
				frmBlackjack.update(g);
				frmBlackjack.getBufferStrategy().show();
				g.dispose();
				try {
					Thread.sleep(View_Constants.FLIP);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * Deal the cards from the deck and move them to their location
	 */
	private void placeCardFromDeck(PlayerType pt, int numberOfCard) {

		java.net.URL sourceimage = getClass().getResource("/resources/b1fv.png"); // unfold card
																			
		JLabel cardToMove = new JLabel(); // the moving card
		if (pt.equals(PlayerType.DEALER)) {
			frmBlackjack.getContentPane().add(cardToMove);
			unfoldDealerCards.add(cardToMove);
		} else {
			frmBlackjack.getContentPane().add(cardToMove, 0);
			unfoldUserCards.add(cardToMove);
		}
		BufferedImage imageToMove = null;
		try {
			imageToMove = ImageIO.read(sourceimage);
			cardToMove.setIcon(new ImageIcon(imageToMove));
			cardToMove.setBounds(View_Constants.START_POINT_X,
					View_Constants.START_POINT_Y,
					View_Constants.USER_CARD_WIDTH,
					View_Constants.USER_CARD_HEIGHT);
		} catch (IOException e) {
			e.printStackTrace();
		}
		int x = View_Constants.START_POINT_X;
		int y = View_Constants.START_POINT_Y;
		frmBlackjack.createBufferStrategy(View_Constants.BUFFER);
		Graphics g = frmBlackjack.getBufferStrategy().getDrawGraphics();
		frmBlackjack.update(g);
		cardToMove.setLocation(x, y);
		frmBlackjack.getBufferStrategy().show();
		g.dispose();
		if (pt.equals(PlayerType.DEALER)) {
			int xToMove = View_Constants.DEALER_PANE_X_LOCATION
					+ View_Constants.DEALER_PANE_WIDTH
					- View_Constants.USER_CARD_WIDTH
					- View_Constants.SPACE_BETWEEN_CARDS * (numberOfCard - 1);
			int xMovement = xToMove - x;
			for (int i = 0; i < xMovement; i++) {
				x++;

				// use buffered strategy for the graphic movement
				bufferedMovement(frmBlackjack, cardToMove, g, x, y);
			}
		} else {
			int xToMove = View_Constants.USER_PANE_X_LOCATION
					+ View_Constants.SPACE_BETWEEN_CARDS * (numberOfCard - 1);
			int xMovement = x - xToMove;
			for (int i = 0; i < xMovement; i++) {
				x--;

				// use buffered strategy for the graphic movement
				bufferedMovement(frmBlackjack, cardToMove, g, x, y);
			}
		}
	}

	/**
	 * starts the card dealing in the start of the game. deals the cards to the
	 * dealer and the user alternately
	 */
	private void startNewGameGraphic() {
		PlayerType pt = PlayerType.USER;
		numberOfUserCards = 0;
		numberOfDealerCards = 0;
		for (int i = 1; i <= View_Constants.NUMBER_OF_CARDS_START; i++) {
			if (pt.equals(PlayerType.USER)) {
				numberOfUserCards++;
				pt = PlayerType.DEALER;
				placeCardFromDeck(pt, numberOfUserCards);
			} else {
				numberOfDealerCards++;
				pt = PlayerType.USER;
				placeCardFromDeck(pt, numberOfDealerCards);
			}
		}
	}

	/**
	 * create the buffered strategy in the frame. in order to avoid flickering
	 * while moving.
	 * 
	 * @param JFrame
	 *            ,JLabel,Graphics,int,int
	 */
	private void bufferedMovement(JFrame bf, JLabel mc, Graphics g, int x, int y) {
		g = bf.getBufferStrategy().getDrawGraphics();
		bf.update(g);
		mc.setLocation(x, y);
		bf.getBufferStrategy().show();
		g.dispose();
	}

	/**
	 * Sets the Deal button functionality and listeners
	 */
	private void setDealFunc() {
		btnDeal.addActionListener(new ActionListener() // sets the listener for the "DEAL" button.
		{
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (!isAnimation) {
					if (Long.parseLong(currentBet.getText()) != 0) {
						myController.ClickedDeal();
						freshStart(); // clean the table
						light.setVisible(false);
						dealerLabels = new ArrayList<JLabel>();
						userLabels = new ArrayList<JLabel>();
						unfoldUserCards = new ArrayList<JLabel>();
						unfoldDealerCards = new ArrayList<JLabel>();
						myController.initialize();
						// disable the buttons while dealing
						btnDeal.setEnabled(false);
						btnHit.setEnabled(false);
						btnStand.setEnabled(false);
						btnReset.setEnabled(false);
						// show the movement graphics
						startNewGameGraphic();
						flipTheIntialCards(); // flip the cards
						setUserScoreValue();
						updateUserScore();
						// enable the buttons
						if (myController.checkGameStatus(PlayerType.USER) == 1) {
							setMessageBoard("  Dealer's Turn");
							setLightAbove(PlayerType.DEALER);
							flipSecondDealerCard();
							setDealerScoreValue();
							updateDealerScore();
							if (myController.getPlayerScore(PlayerType.DEALER) != 21) {
								setMessageBoard("    BlackJack!");
								isUserWon = true;
								myController.updateTotalScore(isUserWon,
										Long.parseLong(currentBet.getText()));
								animationCleanBet.start();
							} else {
								setMessageBoard("     You Lost!");
								isUserWon = false;
								myController.updateTotalScore(isUserWon,
										Long.parseLong(currentBet.getText()));

								animationCleanBet.start();
							}
							btnDeal.setEnabled(true);
							btnReset.setEnabled(true);
						} else {
							setMessageBoard("Choose an action");
							btnHit.setEnabled(true);
							btnStand.setEnabled(true);
							setLightAbove(PlayerType.USER);
						}

					} else {
						setMessageBoard(" Please bet first");
					}
				}
			}

		});
	}

	/**
	 * Sets the Reset button functionality and listeners
	 */
	private void setResetFunc() {
		btnReset.addActionListener(new ActionListener() // sets the listener for the "Reset" button.
		{
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (!isAnimation) {
					int option = JOptionPane.showConfirmDialog(null,
							"Are you sure you want to reset the game?",
							"RESET", JOptionPane.YES_NO_OPTION,
							JOptionPane.QUESTION_MESSAGE);
					if (option == JOptionPane.YES_OPTION) {
						myController.resetGame();
						btnDeal.setEnabled(true);
						freshStart(); // clean the table
						myController.clearBet();
						updateBet();
						updateTotalScore();
						light.setVisible(false);
					}
				}
			}
		});
	}

	/**
	 * clean the table in order to start new game
	 */
	private void freshStart() {
		setMessageBoard("");
		updateRoundboard();
		if (userLabels != null) {
			for (JLabel card : userLabels) {
				frmBlackjack.remove(card);
				frmBlackjack.repaint();
			}
		}
		if (dealerLabels != null) {
			for (JLabel card : dealerLabels) {
				frmBlackjack.remove(card);
				frmBlackjack.repaint();
			}
		}
		if (unfoldUserCards != null) {
			for (JLabel card : unfoldUserCards) {
				frmBlackjack.remove(card);
				frmBlackjack.repaint();
			}
		}
		if (unfoldDealerCards != null) {
			for (JLabel card : unfoldDealerCards) {
				frmBlackjack.remove(card);
				frmBlackjack.repaint();
			}
		}
		frmBlackjack.getContentPane().remove(userScoreValue);
		frmBlackjack.getContentPane().remove(dealerScoreValue);
	}

	/**
	 * Sets the score value graphics of the user hand.
	 */
	private void setUserScoreValue() {
		userScoreValue.setForeground(Color.black);
		userScoreValue.setFont(new Font("Tiresias PCFont Z", Font.BOLD, 18));
		userScoreValue.setBounds(View_Constants.USER_SCORE_X_LOCATION,
				View_Constants.USER_SCORE_Y_LOCATION,
				View_Constants.USER_SCORE_WIDTH,
				View_Constants.USER_SCORE_HEIGHT);
		frmBlackjack.getContentPane().add(userScoreValue);
	}

	/**
	 * update the score of the user after hit.
	 */
	private void updateUserScore() {
		int score = myController.getPlayerScore(PlayerType.USER);
		if (score < 10)
			userScoreValue.setText("0" + score);
		else
			userScoreValue.setText("" + score);
	}

	/**
	 * Sets the score value graphics of the dealer hand.
	 */
	private void setDealerScoreValue() {
		dealerScoreValue.setForeground(Color.black);
		dealerScoreValue.setFont(new Font("Tiresias PCFont Z", Font.BOLD, 18));
		dealerScoreValue.setBounds(View_Constants.DEALER_SCORE_X_LOCATION,
				View_Constants.DEALER_SCORE_Y_LOCATION,
				View_Constants.DEALER_SCORE_WIDTH,
				View_Constants.DEALER_SCORE_HEIGHT);
		frmBlackjack.getContentPane().add(dealerScoreValue);
	}

	/**
	 * locates the message board in the JFrame
	 */
	private void locateMessageBoard() {
		messageBoard.setForeground(Color.white);
		messageBoard.setFont(new Font("Segoe Print", Font.BOLD, 18));
		messageBoard.setBounds(View_Constants.M_X_LOCATION,
				View_Constants.M_Y_LOCATION, View_Constants.M_WIDTH,
				View_Constants.M_HEIGHT);
		frmBlackjack.getContentPane().add(messageBoard);
	}

	/**
	 * sets the message board text
	 */
	private void setMessageBoard(String m) {
		messageBoard.setText(m);
		messageBoard.repaint();
	}

	/**
	 * locates the round board in the JFrame
	 */
	private void locateRoundBoard() {
		roundboard.setForeground(Color.white);
		roundboard.setFont(new Font("Segoe Print", Font.BOLD, 16));
		roundboard.setBounds(View_Constants.ROUND_X_LOCATION,
				View_Constants.ROUND_Y_LOCATION, View_Constants.ROUND_WIDTH,
				View_Constants.ROUND_HEIGHT);
		frmBlackjack.getContentPane().add(roundboard);
	}

	/**
	 * locates the current board in the JFrame
	 */
	private void locateCurrentBet() {
		currentBet.setForeground(Color.white);
		currentBet.setFont(new Font("Segoe Print", Font.BOLD, 16));
		currentBet.setBounds(View_Constants.CURRENT_BET_X_LOCATION,
				View_Constants.CURRENT_BET_Y_LOCATION,
				View_Constants.CURRENT_BET_WIDTH,
				View_Constants.CURRENT_BET_HEIGHT);
		frmBlackjack.getContentPane().add(currentBet);
	}

	/**
	 * updates the total score board
	 */
	private void updateTotalScore() {
		try {
			long totalScore = myController.getScore();
			totalScore -= myController.getCurrentBet();
			this.totalScore.setText("" + totalScore);
		} catch (NullPointerException e) // in case this is the first time
		{
			this.totalScore.setText("" + model.BlackJackModel.intialScore);
		}
	}

	/**
	 * locates the total score board in the JFrame
	 */
	private void locateTotalScore() {
		totalScore.setForeground(Color.white);
		totalScore.setFont(new Font("Segoe Print", Font.BOLD, 16));
		totalScore.setBounds(View_Constants.TOTAL_SCORE_X_LOCATION,
				View_Constants.TOTAL_SCORE_Y_LOCATION,
				View_Constants.TOTAL_SCORE_WIDTH,
				View_Constants.TOTAL_SCORE_HEIGHT);
		frmBlackjack.getContentPane().add(totalScore);
	}

	/**
	 * updated the current bet according to the model logic info
	 */
	private void updateCurrentBet() {
		try {
			long currentBet = myController.getCurrentBet();
			this.currentBet.setText("" + currentBet);
		} catch (NullPointerException e) // in case this is the first time
		{
			this.currentBet.setText("0");
		}
	}

	/**
	 * sets the round board text
	 */
	private void updateRoundboard() {
		try {
			int currentRound = myController.getRoundNumber();
			if (currentRound < 10) {
				roundboard.setText("ROUND 0" + currentRound);
			} else {
				roundboard.setText("ROUND " + currentRound);
			}
		} catch (NullPointerException e) // in case this is the first time
		{
			roundboard.setText("ROUND 00");
		}

	}

	/**
	 * update the score of the dealer after hit.
	 */
	private void updateDealerScore() {
		int score = myController.getPlayerScore(PlayerType.DEALER);
		if (score < 10)
			dealerScoreValue.setText("0" + score);
		else
			dealerScoreValue.setText("" + score);
	}

	/**
	 * Sets the Hit button functionality and listeners
	 */
	private void setHitFunc() {
		btnHit.addActionListener(new ActionListener() // sets the listener for the "Hit" button.
		{
			@Override
			public void actionPerformed(ActionEvent arg0) {
				btnStand.setEnabled(false);
				btnHit.setEnabled(false);
				int userGameStatus = myController.ClickedHit();
				numberOfUserCards++;
				setUserCards(myController.getUserStrings());
				placeCardFromDeck(PlayerType.USER, numberOfUserCards);
				flipCard(PlayerType.USER, numberOfUserCards);
				updateUserScore();
				if (userGameStatus == 0) // in case the user busted
				{
					setMessageBoard("     Busted!");
					isUserWon = false;
					myController.updateTotalScore(isUserWon,
							Long.parseLong(currentBet.getText()));
					animationCleanBet.start();
					btnDeal.setEnabled(true);
					btnReset.setEnabled(true);
				}
				if (userGameStatus == 1) // in case the user reached 21.
				{
					setLightAbove(PlayerType.DEALER);
					setMessageBoard("  Dealer's Turn");
					timerToSetDealerMoves.start();
				}
				if (userGameStatus == 2) // in case the user can continue hitting
				{
					btnStand.setEnabled(true);
					btnHit.setEnabled(true);
				}
			}
		});
	}

	/**
	 * locates the light in the JFrame and set its size
	 */
	private void locateLight() {
		java.net.URL sourceimage = getClass().getResource("/resources/light.png"); // image of light bulb
																				
		BufferedImage lightImg = null;
		try {
			lightImg = ImageIO.read(sourceimage);
			light.setIcon(new ImageIcon(lightImg));
			light.setSize(View_Constants.LIGHT_WIDTH,
					View_Constants.LIGHT_HEIGHT);
			light.setVisible(false);
			frmBlackjack.add(light);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * let the light bulb location according to the current player
	 */
	private void setLightAbove(PlayerType pt) {
		light.setVisible(true);
		if (pt.equals(PlayerType.USER)) {
			light.setLocation(View_Constants.LIGHT_X_USER_LOCATION,
					View_Constants.LIGHT_Y_USER_LOCATION);
		} else {
			light.setLocation(View_Constants.LIGHT_X_DEALER_LOCATION,
					View_Constants.LIGHT_Y_DEALER_LOCATION);
		}
	}

	/**
	 * Sets the Stand button functionality and listeners
	 */
	private void setStandFunc() {
		btnStand.addActionListener(new ActionListener() // sets the listener for the "Hit" button.
		{
			@Override
			public void actionPerformed(ActionEvent arg0) {
				btnStand.setEnabled(false);
				btnHit.setEnabled(false);
				setLightAbove(PlayerType.DEALER);
				setMessageBoard("  Dealer's Turn");
				timerToSetDealerMoves.start();

			}
		});
	}

	/**
	 * sets the graphic moves of the dealer
	 */
	private void setDealerMoves() {
		int dealerGameStatus;
		flipSecondDealerCard();
		setDealerScoreValue();
		updateDealerScore();
		do {
			dealerGameStatus = myController.DealerHit();
			if (dealerGameStatus != 3) {
				numberOfDealerCards++;
				setDealerCards(myController.getDealerStrings());
				placeCardFromDeck(PlayerType.DEALER, numberOfDealerCards);
				flipCard(PlayerType.DEALER, numberOfDealerCards);
			}
			updateDealerScore();
		} while (dealerGameStatus == 2);
		updateDealerScore();
		endGameStatus(dealerGameStatus);
		myController.updateTotalScore(isUserWon,
				Long.parseLong(currentBet.getText()));
		animationCleanBet.start();
		timerToSetDealerMoves.stop();
	}

	/**
	 * checks the game status in the end of a round
	 */
	private void endGameStatus(int dealerGameStatus) {
		if (dealerGameStatus == 0) {
			setMessageBoard("     You Won!");
			isUserWon = true;
		} else {
			if (myController.checkIfPlayerWon() == 1) {
				setMessageBoard("     You Won!");
				isUserWon = true;
			} else if (myController.checkIfPlayerWon() == 0) {
				setMessageBoard("     You Lost!");
				isUserWon = false;
			} else {
				setMessageBoard("     You Lost!");
				isUserWon = false;
			}
		}
		btnHit.setEnabled(false);
		btnStand.setEnabled(false);
		btnDeal.setEnabled(true);
		btnReset.setEnabled(true);
	}

	/**
	 * flip the second card of the dealer
	 */
	private void flipSecondDealerCard() {
		myController.flipDealerCard(); // makes the card face up in model logic
		setDealerCards(myController.getDealerStrings());
		flipCard(PlayerType.DEALER, 1);
	}

	/**
	 * clear the bet amount in animation this function will be called until we
	 * will stop the timer object - animationCleanBet
	 */
	private void resetCurrentBetAnimation() {
		isAnimation = true; // indicates that the animation is on going and the buttons won't work
		String currentBetString = currentBet.getText();
		long bet = Long.parseLong(currentBetString);
		long totalScore = myController.getScore();
		long currentTotalScore = Long.parseLong(this.totalScore.getText());
		if (bet > 0) {
			bet--;
			currentBet.setText("" + bet);
		}
		if (currentTotalScore < totalScore) {
			currentTotalScore++;
			this.totalScore.setText("" + currentTotalScore);
		}
		if (currentTotalScore > totalScore) {
			currentTotalScore--;
			this.totalScore.setText("" + currentTotalScore);
		}

		if (bet == 0 && currentTotalScore == totalScore) {
			if (myController.isGameOver()) {
				setMessageBoard("  GAME OVER");
				btnDeal.setEnabled(false);
				btnReset.setEnabled(true);
				bet_2.setEnabled(true);
				bet_5.setEnabled(true);
				bet_10.setEnabled(true);
				bet_100.setEnabled(true);
			}
			isAnimation = false; // finished animation
			animationCleanBet.stop(); // stops the timer when finished
		}
	}

}
