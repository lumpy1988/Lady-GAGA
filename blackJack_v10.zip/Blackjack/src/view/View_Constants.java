/**
 * @author Idan , Kosta , Or , Elinor
 */
package view;
/**
 * View_Constants - Constants Class
 */
public final class View_Constants 
{
	//frame pane
	public static final int FRAME_PANE_X_LOCATION = 100;
	public static final int FRAME_PANE_Y_LOCATION = 100;
	public static final int FRAME_PANE_WIDTH = 1100;
	public static final int FRAME_PANE_HEIGHT = 759;
	
	//hit button
	public static final int HIT_PANE_X_LOCATION = 415;
	public static final int HIT_PANE_Y_LOCATION = 522;
	public static final int HIT_PANE_WIDTH = 90;
	public static final int HIT_PANE_HEIGHT = 90;
	
	//stand button
	public static final int STAND_PANE_X_LOCATION = 626;
	public static final int STAND_PANE_Y_LOCATION = 522;
	public static final int STAND_PANE_WIDTH = 90;
	public static final int STAND_PANE_HEIGHT = 90;
	
	//deal button
	public static final int DEAL_PANE_X_LOCATION = 999;
	public static final int DEAL_PANE_Y_LOCATION = 509;
	public static final int DEAL_PANE_WIDTH = 82;
	public static final int DEAL_PANE_HEIGHT = 80;
	
	//reset button
	public static final int RESET_PANE_X_LOCATION = 59;
	public static final int RESET_PANE_Y_LOCATION = 510;
	public static final int RESET_PANE_WIDTH = 82;
	public static final int RESET_PANE_HEIGHT = 80;
	
	//user pane
	public static final int USER_PANE_X_LOCATION = 269;
	public static final int USER_PANE_Y_LOCATION = 350;
	public static final int USER_PANE_WIDTH = 210;
	public static final int USER_PANE_HEIGHT = 152;
	
	//dealer pane
	public static final int DEALER_PANE_X_LOCATION = 645;
	public static final int DEALER_PANE_Y_LOCATION = 350;
	public static final int DEALER_PANE_WIDTH = 210;
	public static final int DEALER_PANE_HEIGHT = 152;
	
	//user score value
	public static final int USER_SCORE_X_LOCATION = 256;
	public static final int USER_SCORE_Y_LOCATION = 320;
	public static final int USER_SCORE_WIDTH = 30;
	public static final int USER_SCORE_HEIGHT = 30;
	
	//dealer score value
	public static final int DEALER_SCORE_X_LOCATION = 860;
	public static final int DEALER_SCORE_Y_LOCATION = 320;
	public static final int DEALER_SCORE_WIDTH = 30;
	public static final int DEALER_SCORE_HEIGHT = 30;
	
	//space between cards
	public static final int SPACE_BETWEEN_CARDS = 13;
	
	//dealer card
	public static final int DEALER_CARD_X_LOCATION = 10;
	public static final int DEALER_CARD_Y_LOCATION = 24;
	public static final int DEALER_CARD_WIDTH = 71;
	public static final int DEALER_CARD_HEIGHT = 96;
	
	//user card
	public static final int USER_CARD_X_LOCATION = 10;
	public static final int USER_CARD_Y_LOCATION = 24;
	public static final int USER_CARD_WIDTH = 71;
	public static final int USER_CARD_HEIGHT = 96;
	
	//message board
	public static final int M_X_LOCATION = 492;
	public static final int M_Y_LOCATION = 634;
	public static final int M_WIDTH = 300;
	public static final int M_HEIGHT = 50;
	
	//round board
	public static final int ROUND_X_LOCATION = 792;
	public static final int ROUND_Y_LOCATION = 17;
	public static final int ROUND_WIDTH = 300;
	public static final int ROUND_HEIGHT = 50;
	
	//start point of movement
	public static final int START_POINT_X = 529;
	public static final int START_POINT_Y = 374;
	//deck
	public static final int DECK_HEIGHT = 110;
	public static final int DECK_Y = 360;
	//diagonal movement
	public static final int HORIZE_MOVEMENT = START_POINT_X - (DEALER_PANE_X_LOCATION + DEALER_CARD_X_LOCATION);
	
	//total number of cards
	public static final int NUMBER_OF_CARDS_START = 4;
	//buffer size
	public static final int BUFFER = 2;
	//flip sleep time
	public static final int FLIP = 10;
	//delay in dealer's moves
	public static final int DELAER_DELAY = 2000;
	
	//light bulb size
	public static final int LIGHT_X_USER_LOCATION = 165;
	public static final int LIGHT_X_DEALER_LOCATION = 768;
	public static final int LIGHT_Y_USER_LOCATION = 173;
	public static final int LIGHT_Y_DEALER_LOCATION = 175;
	public static final int LIGHT_WIDTH = 150;
	public static final int LIGHT_HEIGHT = 150;
	
	//bet numbers
	public static final int BET_X_LOCATION = 946;
	public static final int BET_Y_LOCATION = 660;
	public static final int BET_WIDTH = 82;
	public static final int BET_HEIGHT = 80;
	public static final int BET_SPACE = 66;
	
	//current bet board
	public static final int CURRENT_BET_X_LOCATION = 810;
	public static final int CURRENT_BET_Y_LOCATION = 615;
	public static final int CURRENT_BET_WIDTH = 100;
	public static final int CURRENT_BET_HEIGHT = 50;
	
	//total score board
	public static final int TOTAL_SCORE_X_LOCATION = 962;
	public static final int TOTAL_SCORE_Y_LOCATION = 615;
	public static final int TOTAL_SCORE_WIDTH = 100;
	public static final int TOTAL_SCORE_HEIGHT = 50;
}
