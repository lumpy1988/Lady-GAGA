/**
 * @author Idan , Kosta , Or , Elinor
 */
package model;
/**
 * BlackJackModel Class
 * MVS - model
 * implements CardGame 
 */
public class BlackJackModel implements CardGame 
{	
	private BlackJackDealer dealer; 
	private BlackJackPlayer player;
	private long currentScore;
	private int round;
	private final int oddRoundScore = 2;
	private final int evenRoundScore = 3;
	public final static long intialScore = 100;
	private long currentBet; 
	
	/**
	 * BlackJackModel Constructor.
	 */
	public BlackJackModel()
	{
		Deck d = new Deck();
		dealer = new BlackJackDealer(d);
		player = new BlackJackPlayer(PlayerType.USER);
		currentScore = intialScore;
		round = 0;
		
	}
	
	
	/**
	 * starts the game.
	 */
	@Override
	public void startGame() 
	{
		currentBet=0;
		dealer.initializeHand();
		player.initializeHand();
		dealer.getDeck().shuffle();
		initializeGame();
	}

	/**
	 * initialize the game in the model point of view and deal 2 cards to the dealer and the user.
	 */
	@Override
	public void initializeGame() 
	{
		BlackJackCard a;
		//Player first card:
		a = dealer.dealCard();
		a.faceUp();
		player.takeCard(a);
		//Dealer first card:
		BlackJackCard b;
		b = (BlackJackCard) dealer.dealCard();
		b.faceDown();
		dealer.takeCard(b);
		//Player second card:
		BlackJackCard c;
		c = (BlackJackCard) dealer.dealCard();
		c.faceUp();
		player.takeCard(c);
		//dealer second card - Face down:
		BlackJackCard d;
		d = (BlackJackCard) dealer.dealCard();
		d.faceUp();
		dealer.takeCard(d);		
	}

	/**
	 * return the user player
	 */
	public BlackJackPlayer getCurrentPlayer() 
	{
		return player;
	}
	
	/**
	 * sets the user player
	 */
	public void setCurrentPlayer(BlackJackPlayer currentPlayer) 
	{
		this.player = currentPlayer;
	}

	/**
	 * get the dealer player
	 */
	public BlackJackDealer getDealer() 
	{
		return dealer;
	}
	
	/**
	 * check the game status of the current user
	 * @return int. 
	 * if the current player got busted return 0. 
	 * if the current player got 21 return 1. 
	 * if the current player can continue to hit return 2.
	 */
	public int CheckStatus (PlayerType pt)
	{
		BlackJackCard a;
		a = dealer.dealCard();
		a.faceUp();
		if (pt.equals(PlayerType.USER))
		{
			if (player.isbusted())
			{
				return 0;
			}
			if (player.got21())
			{
				return 1;
			}
			else
			{
				return 2;	
			}
		}
		else
		{
			if (dealer.isbusted())
			{
				return 0;
			}
			if (dealer.checkSoft17() || dealer.getHand().score(pt) < 17)
			{
				return 2;	
			}
			else
			{
				return 1;
			}
		}	
	}
	
	
	/**
	 * deal card to the current player.
	 * @return BlackJackCard. 
	 */
	public BlackJackCard dealCard(PlayerType pt)
	{
		BlackJackCard a;	
		a = pt.equals(PlayerType.USER) ? player.hit(dealer) : dealer.hit(dealer);
		a.faceUp();
		return a;
	}
	
	/**
	 * return the current score of the game
	 * @return long. 
	 */
	public long getCurrentScore()
	{
		return currentScore;
	}
	
	/**
	 * return the current round of the game
	 * @return integer. 
	 */
	public int getRound()
	{
		return round;
	}
	
	/**
	 * set the next round 
	 */
	public void nextRound()
	{
		round++;
	}
	
	/**
	 * get round number, indication if the player won or lost, and the bet mount.
	 * calculates the current score 
	 */
	public void calculateScore(boolean playerWon, long bet)
	{
		if (playerWon)
		{
			if (round%2==0)
			{
				currentScore +=bet*oddRoundScore;
			}
			else
			{
				currentScore +=bet*evenRoundScore;
			}
		}
		else
		{
			if (round%2==0)
			{
				currentScore -=bet*oddRoundScore;
			}
			else
			{
				currentScore -=bet*evenRoundScore;
			}
		}
	}
	
	/**
	 * checks if the game is over (score is < 0) 
	 */
	public boolean isGameOver()
	{
		return (currentScore <=0);
	}
	
	/**
	 * reset the game score and start from scratch
	 */
	public void reset()
	{
		currentScore = intialScore;
		round = 0;
	}
	
	/**
	 * gets a bet and check if you can add it to the current bet in the round
	 * @return true if added and false if not
	 */
	public boolean updateBet(int bet)
	{
		if ((bet+currentBet)<=currentScore)
		{
			currentBet+=bet;
			return true;
		}
		else
			return false;
	}
	
	/**
	 * return the bet number
	 * @return long
	 */
	public long getBet()
	{
		return currentBet;
	}
	
	/**
	 * reset the bet after clear was chosen
	 */
	public void resetBet()
	{
		currentBet=0;
	}

	
	
}
