/**
 * @author Idan , Kosta , Or , Elinor
 */
package model;
/**
 * PlayerType enum
 */
public enum PlayerType 
{
	USER, DEALER;
}
