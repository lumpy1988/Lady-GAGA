/**
 * @author Idan , Kosta , Or , Elinor
 */
package model;
/**
 * Facing interface
 */
public interface Facing 
{
	public void faceUp(); // set the face up
	public void faceDown(); // set the face down
}
