/**
 * @author Idan , Kosta , Or , Elinor
 */
package model;
/**
 * Face enum
 */
public enum Face 
{
	UP, DOWN;
}
